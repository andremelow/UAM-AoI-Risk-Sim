function state = step_read_positions(state, drones, ~, time, slot, cfg)
% STEP_READ_POSITIONS  Reads drone positions, updates active set.

N = cfg.numDrones;
state.activeDrones = [];
state.activePos    = zeros(N, 3);

for i = 1:N
    % Mark finished drones as invalid for scheduling — preserve time-series data
    % h1Time, h2Time, riskTime etc. must NOT be cleared here: collect_results
    % reads them after the simulation ends. Clearing here wipes all flight data.
    if slot > state.endSlots(i)
        state.pendingMsg{i}.valid = false;   % stop scheduling this drone
    end

    % Skip inactive
    if slot < state.startSlots(i) || slot > state.endSlots(i)
        state.pendingMsg{i}.valid = false;
        continue;
    end

    [pos, ~] = read(drones{i});
    if i == 1 && mod(slot, 50) == 0
        fprintf('t=%.2f drone1 pos=[%g %g %g %g %g %g %g]\n', time, pos(1:7));
    end
    
    if any(isnan(pos)), continue; end

    state.pendingMsg{i}.pos       = pos(1:3);
    state.pendingMsg{i}.slot      = slot;
    state.pendingMsg{i}.valid     = true;
    state.activeDrones(end+1)     = i; %#ok<AGROW>
    state.activePos(i,:)          = pos(1:3);
end
end
