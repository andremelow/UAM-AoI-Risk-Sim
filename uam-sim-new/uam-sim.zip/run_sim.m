function results = run_sim(cfg)
% RUN_SIM  UAM-AoI-Risk Simulator — modular entry point.
%
%  Usage:
%    run_sim()                              % default config
%    run_sim(build_scenario_config())       % explicit config
%    cfg = build_scenario_config(); cfg.numDrones = 30; run_sim(cfg);
%
%  The monolithic UAM_AoI_Control_Sim_WithRisk.m is replaced by this
%  orchestrator, which delegates to focused modules in core/, viz/, policies/.

clc; close all;

if nargin < 1, cfg = build_scenario_config(); end

% Ensure all subdirectories are on the path
setup_paths();

cfg = validate_uam_config(cfg);

% --- Initialisation ---
[scene, drones, infra] = init_scenario(cfg);
state                  = init_state(cfg, infra);
[rhoMap, mapGrid]      = init_ground_risk(cfg);
dashboard              = init_dashboard(cfg, rhoMap, mapGrid);

% --- Main loop ---
while advance(scene)
    time = scene.CurrentTime;              % seconds — uavScenario API only
    slot = round(time * cfg.updateRate);   % integer slot index

    state = step_read_positions(state, drones, infra, time, slot, cfg);

    % Early exit: all drones have landed
    if slot > max(state.endSlots) && isempty(state.activeDrones)
        break;
    end

    state = step_traffic(state, slot, cfg);

    [txSlots, state] = schedule_sources(state, slot, cfg);

    state = step_channel(state, infra, time, cfg);

    state = step_transmit(state, txSlots, slot, cfg);

    % Record scheduled source and tx outcome per drone
    for i = state.activeDrones
        % Decode which source (if any) was scheduled for this drone
        src_c2  = 2*(i-1)+1;  src_vid = 2*(i-1)+2;
        if any(txSlots == src_c2)
            sched_val = 1;
        elseif any(txSlots == src_vid)
            sched_val = 2;
        else
            sched_val = 0;
        end
        state.schedSeries{i}(end+1) = sched_val;
        state.schedSlots{i}(end+1)  = slot;
        % tx success: 1 if scheduled and SNR ok, 0 if scheduled and failed, -1 not scheduled
        if sched_val > 0
            snr_ok = (~isnan(state.snrLast(i))) && (state.snrLast(i) >= cfg.thresholdSNR);
            state.txSuccSeries{i}(end+1) = double(snr_ok);
        else
            state.txSuccSeries{i}(end+1) = -1;
        end
        state.txSuccSlots{i}(end+1) = slot;
    end

    state = step_risk(state, rhoMap, mapGrid, slot, cfg);

    % Accumulate per-slot series for CSV export and SNR spatial display
    for i = state.activeDrones
        snr_i = state.snrLast(i);
        % SNR spatial trail (dashboard)
        if ~isnan(snr_i)
            dashboard.snrNorthHist{i}(end+1) = state.pendingMsg{i}.pos(1);
            dashboard.snrValHist{i}(end+1)   = snr_i;
        end
        % Dense series for CSV export
        state.snrSeries{i}(end+1)  = state.snrLast(i);
        state.snrSlots{i}(end+1)   = slot;
    end

    update_dashboard(dashboard, state, scene, txSlots, slot, cfg);
end

% --- Post-simulation ---
results = collect_results(state, infra, cfg);
if isfield(cfg, 'csvExport') && cfg.csvExport
    outDir = 'csv_export';
    if isfield(cfg, 'csvDir'), outDir = cfg.csvDir; end
    export_csv(results, cfg, outDir);
end

fprintf('\nSimulation complete.\n');
end
